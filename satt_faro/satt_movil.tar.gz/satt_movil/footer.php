<div id="footer" >
<? if( $_SESSION[satt_movil] ){ ?>
<a href="logout.php">Salir</a>
<? } ?>
</div>
</body>
</html>